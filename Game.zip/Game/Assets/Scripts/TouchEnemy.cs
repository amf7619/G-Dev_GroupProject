﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TouchEnemy : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            SceneManager.LoadScene("Level1");
        }
    }

    public void OnGUI()
    {
        // Change color
        GUI.color = Color.black;

        // Increase text size
        GUI.skin.box.fontSize = 18;

        // Draw the GUI box with text
        GUI.Box(new Rect(20, 10, 300, 30), "This is working");
        GUI.Box(new Rect(20, 40, 300, 30), "Working very nice");

        GUI.skin.box.wordWrap = true;
    }
}
